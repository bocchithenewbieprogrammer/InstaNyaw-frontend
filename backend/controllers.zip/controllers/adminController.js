const User = require("../models/User");

// Helper: prevent modifying head admin
const isHeadAdmin = (user) => user.role === "headadmin";

// 📌 1. Get all users
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password");
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 📌 2. Ban user
exports.banUser = async (req, res) => {
  try {
    const target = await User.findById(req.params.id);
    if (!target) return res.status(404).json({ message: "User not found" });

    // 🔒 Prevent banning head admin or self
    if (isHeadAdmin(target)) return res.status(403).json({ message: "Cannot ban Head Admin" });
    if (target.id === req.user.id) return res.status(403).json({ message: "You cannot ban yourself" });

    target.isBanned = true;
    await target.save();

    res.json({ message: `${target.username} has been banned`, user: target });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 📌 3. Unban user
exports.unbanUser = async (req, res) => {
  try {
    const target = await User.findById(req.params.id);
    if (!target) return res.status(404).json({ message: "User not found" });

    target.isBanned = false;
    await target.save();

    res.json({ message: `${target.username} has been unbanned`, user: target });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 📌 4. Update role (promote/demote)
exports.updateRole = async (req, res) => {
  try {
    const { role } = req.body;
    const target = await User.findById(req.params.id);

    if (!target) return res.status(404).json({ message: "User not found" });

    // 🔒 Only HEAD ADMIN can promote to admin or headadmin
    if ((role === "admin" || role === "headadmin") && req.user.role !== "headadmin") {
      return res.status(403).json({ message: "Only Head Admin can assign admin roles" });
    }

    // 🔒 Protect head admin
    if (isHeadAdmin(target) && req.user.role !== "headadmin") {
      return res.status(403).json({ message: "Cannot modify Head Admin" });
    }

    target.role = role;
    await target.save();

    res.json({ message: `${target.username} is now ${role}`, user: target });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 📌 5. Delete user (only headadmin)
exports.deleteUser = async (req, res) => {
  try {
    const target = await User.findById(req.params.id);
    if (!target) return res.status(404).json({ message: "User not found" });

    if (req.user.role !== "headadmin")
      return res.status(403).json({ message: "Only Head Admin can delete accounts" });

    if (isHeadAdmin(target))
      return res.status(403).json({ message: "Cannot delete Head Admin" });

    await User.deleteOne({ _id: target.id });

    res.json({ message: `${target.username} has been deleted` });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

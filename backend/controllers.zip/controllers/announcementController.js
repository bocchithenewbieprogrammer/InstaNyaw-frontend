const Announcement = require("../models/Announcement");

// Create announcement
exports.createAnnouncement = async (req, res) => {
  try {
    const { title, content } = req.body;

    const announcement = new Announcement({
      title,
      content,
      createdBy: req.user._id,
    });

    await announcement.save();
    res.status(201).json(announcement);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get all announcements
exports.getAnnouncements = async (req, res) => {
  try {
    const announcements = await Announcement.find()
      .sort({ createdAt: -1 })
      .populate("createdBy", "username firstName lastName avatar");

    res.json(announcements);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
// Update announcement
exports.updateAnnouncement = async (req, res) => {
  try {
    const announcement = await Announcement.findById(req.params.id);
    if (!announcement) {
      return res.status(404).json({ message: "Announcement not found" });
    }

    const { title, content } = req.body;

    if (title !== undefined) announcement.title = title;
    if (content !== undefined) announcement.content = content;

    announcement.updatedAt = Date.now();
    await announcement.save();

    res.json(announcement);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Delete announcement
exports.deleteAnnouncement = async (req, res) => {
  try {
    const announcement = await Announcement.findByIdAndDelete(req.params.id);
    if (!announcement) {
      return res.status(404).json({ message: "Announcement not found" });
    }

    res.json({ message: "Announcement deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Delete announcement (owner or admin)
exports.deleteAnnouncement = async (req, res) => {
  try {
    const announcement = await Announcement.findById(req.params.id);
    if (!announcement) {
      return res.status(404).json({ message: "Announcement not found" });
    }

    // creator or admin
    if (
      announcement.createdBy.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({ message: "Not authorized to delete this announcement" });
    }

    await announcement.deleteOne();
    res.json({ message: "Announcement deleted successfully" });
  } catch (err) {
    console.error("Delete Announcement Error:", err);
    res.status(500).json({ message: "Server error while deleting announcement." });
  }
};

const BirthdayGreeting = require("../models/BirthdayGreeting");
const User = require("../models/User");

// Create greeting
exports.createGreeting = async (req, res) => {
  try {
    const { recipientUsername, message, image } = req.body;

    const recipient = await User.findOne({ username: recipientUsername });
    if (!recipient) {
      return res.status(404).json({ message: "Recipient not found." });
    }

    const greeting = new BirthdayGreeting({
      recipient: recipient._id,
      message,
      image,
      createdBy: req.user._id
    });

    await greeting.save();

    const populatedGreeting = await BirthdayGreeting.findById(greeting._id)
      .populate("createdBy", "username firstName lastName avatar")
      .populate("recipient", "username firstName lastName avatar");

    res.status(201).json(populatedGreeting);

  } catch (error) {
    res.status(500).json({ message: "Failed to post greeting." });
  }
};


// Get greetings
exports.getGreetings = async (req, res) => {
  try {
    const greetings = await BirthdayGreeting.find()
      .sort({ createdAt: -1 })
      .populate("createdBy", "username firstName lastName avatar")
      .populate("recipient", "username firstName lastName avatar");
      

    res.json(greetings);

  } catch (error) {
    res.status(500).json({ message: "Failed to fetch greetings." });
  }
};

// ✅ DELETE birthday greeting
exports.deleteGreeting = async (req, res) => {
  try {
    const greeting = await BirthdayGreeting.findById(req.params.id);
    if (!greeting) return res.status(404).json({ message: "Greeting not found" });

    // only owner (createdBy) OR admin
    if (
      greeting.createdBy.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({ message: "Not authorized to delete this greeting" });
    }

    await greeting.deleteOne();
    res.json({ message: "Greeting deleted successfully" });
  } catch (error) {
    console.error("❌ Error deleting greeting:", error);
    res.status(500).json({ message: "Failed to delete greeting." });
  }
};

// UPDATE Birthday Greeting
exports.updateGreeting = async (req, res) => {
  try {
    const { message, image } = req.body;

    const greeting = await BirthdayGreeting.findById(req.params.id);
    if (!greeting) {
      return res.status(404).json({ message: "Greeting not found" });
    }

    // Only creator or admin can edit
    if (greeting.createdBy.toString() !== req.user._id.toString() &&
        req.user.role !== "admin") {
      return res.status(403).json({ message: "Unauthorized" });
    }

    if (message) greeting.message = message;
    if (image) greeting.image = image;

    await greeting.save();

    const updated = await BirthdayGreeting
      .findById(greeting._id)
      .populate("createdBy", "username firstName lastName avatar")
      .populate("recipient", "username firstName lastName avatar");

    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};



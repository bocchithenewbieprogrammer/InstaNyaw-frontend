const Comment = require("../models/Comment");

exports.addComment = async (req, res) => {
  try {
    const { postId, postType, content } = req.body;

    const comment = await Comment.create({
      postId,
      postType,
      content,
      user: req.user._id
    });

    const populated = await Comment.findById(comment._id).populate("user", "username firstName lastName avatar");

    res.status(201).json(populated);
  } catch (err) {
    res.status(500).json({ message: "Error adding comment" });
  }
};

exports.getComments = async (req, res) => {
  try {
    const { postId, postType } = req.query;

    const comments = await Comment.find({ postId, postType })
      .populate("user", "username firstName lastName avatar")
      .sort({ createdAt: -1 });

    res.json(comments);
  } catch (err) {
    res.status(500).json({ message: "Error loading comments" });
  }
};

const HomePost = require("../models/HomePost");

exports.createHomePost = async (req, res) => {
  try {
    const { content, image } = req.body;

    if (!content) return res.status(400).json({ message: "Content required" });

    const post = await HomePost.create({
      user: req.user._id,
      content,
      image: image || "",
    });

    const populated = await HomePost.findById(post._id)
      .populate("user", "username firstName lastName avatar");

    res.status(201).json(populated);

  } catch (error) {
    res.status(500).json({ message: "Error creating post" });
  }
};


// Feed
exports.getAllHomePosts = async (req, res) => {

  try {
    const posts = await HomePost.find()
      .sort({ createdAt: -1 })
      .populate("likes")
      .populate("comments")
      .populate("comments.user")
      .populate("user", "username firstName lastName avatar");

    res.json(posts);

  } catch (error) {
    res.status(500).json({ message: "Error loading posts" });
  }
  const Like = require("../models/Like");
const Comment = require("../models/Comment");

exports.getAllHomePosts = async (req, res) => {
  try {
    const posts = await HomePost.find()
      .sort({ createdAt: -1 })
      .populate("user", "username firstName lastName avatar");

    // 🔥 Attach likeCount + commentCount
    const enriched = await Promise.all(
      posts.map(async (post) => {
        const likeCount = await Like.countDocuments({
          postId: post._id,
          postType: "homepost"
        });

        const commentCount = await Comment.countDocuments({
          postId: post._id,
          postType: "homepost"
        });

        return {
          ...post.toObject(),
          likes: Array(likeCount).fill("x"),   // keep frontend working
          comments: Array(commentCount).fill("x")
        };
      })
    );

    res.json(enriched);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Error loading posts" });
  }
};

};


// ==========================
// Delete Home Post
// ==========================
exports.deleteHomePost = async (req, res) => {
  try {
    const post = await HomePost.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    // Owner OR admin can delete
    if (
      post.user.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({ message: "Not authorized to delete this post" });
    }

    await post.deleteOne();
    res.json({ message: "Post deleted successfully" });
  } catch (err) {
    console.error("Delete HomePost Error:", err);
    res.status(500).json({ message: "Server error while deleting post." });
  }
};

const Like = require("../models/Like");

exports.likePost = async (req, res) => {
  try {
    const { postId, postType } = req.body;

    const existing = await Like.findOne({
      postId,
      postType,
      user: req.user._id
    });

    if (existing) {
      // UNLIKE
      await existing.deleteOne();
      return res.json({ liked: false });
    }

    await Like.create({
      postId,
      postType,
      user: req.user._id
    });

    res.json({ liked: true });
  } catch (err) {
    res.status(500).json({ message: "Like error" });
  }
};

exports.getLikes = async (req, res) => {
  try {
    const { postId, postType } = req.query;
    const likes = await Like.find({ postId, postType });
    res.json(likes);
  } catch (err) {
    res.status(500).json({ message: "Error loading likes" });
  }
};

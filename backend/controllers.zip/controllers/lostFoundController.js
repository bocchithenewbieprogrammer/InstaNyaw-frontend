const LostAndFound = require("../models/LostAndFound");

// ==========================
// Create Entry
// ==========================
exports.createEntry = async (req, res) => {
  try {
    const { title, description, status, image } = req.body;

    const entry = await LostAndFound.create({
      title,
      description,
      status,
      image,
      user: req.user._id,
    });

    const populated = await LostAndFound.findById(entry._id)
      .populate("user", "username firstName lastName avatar");

    res.status(201).json(populated);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


// ==========================
// Get All Entries
// ==========================
exports.getEntries = async (req, res) => {
  try {
    const entries = await LostAndFound.find()
      .sort({ createdAt: -1 })
      .populate("user", "username firstName lastName avatar");

    res.json(entries);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


// ==========================
// Update Entry
// ==========================
exports.updateEntry = async (req, res) => {
  try {
    const entry = await LostAndFound.findById(req.params.id);
    if (!entry) return res.status(404).json({ message: "Item not found" });

    // Auth: owner OR admin
    if (entry.user.toString() !== req.user._id.toString() && req.user.role !== "admin") {
      return res.status(403).json({ message: "Not authorized" });
    }

    const { title, description, status, image } = req.body;

    if (title !== undefined) entry.title = title;
    if (description !== undefined) entry.description = description;
    if (status !== undefined) entry.status = status;
    if (image !== undefined) entry.image = image;

    await entry.save();

    const updated = await LostAndFound.findById(entry._id)
      .populate("user", "username firstName lastName avatar");

    res.json(updated);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


// ==========================
// Delete Entry
// ==========================
// Delete entry
exports.deleteEntry = async (req, res) => {
  try {
    const entry = await LostAndFound.findById(req.params.id);
    if (!entry) return res.status(404).json({ message: "Item not found" });

    // owner or admin
    if (
      entry.user.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({ message: "Not authorized" });
    }

    await entry.deleteOne();
    res.json({ message: "Item deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


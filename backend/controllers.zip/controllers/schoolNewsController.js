const SchoolNews = require("../models/SchoolNews");

// ==========================
// CREATE NEWS
// ==========================
exports.createNews = async (req, res) => {
  try {
    const { title, content } = req.body;

    const news = await SchoolNews.create({
      title,
      content,
      createdBy: req.user._id,
    });

    const populated = await SchoolNews.findById(news._id)
      .populate("createdBy", "username firstName lastName avatar");

    res.status(201).json(populated);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ==========================
// GET ALL NEWS
// ==========================
exports.getNews = async (req, res) => {
  try {
    const news = await SchoolNews.find()
      .sort({ createdAt: -1 })
      .populate("createdBy", "username firstName lastName avatar");

    res.json(news);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ==========================
// UPDATE NEWS
// ==========================
exports.updateNews = async (req, res) => {
  try {
    const { title, content } = req.body;

    const news = await SchoolNews.findById(req.params.id);
    if (!news) return res.status(404).json({ message: "News not found" });

    if (title) news.title = title;
    if (content) news.content = content;
    news.updatedAt = Date.now();

    await news.save();

    const populated = await SchoolNews.findById(news._id)
      .populate("createdBy", "username firstName lastName avatar");

    res.json(populated);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ==========================
// DELETE NEWS
// ==========================
// Delete news (owner or admin)
exports.deleteNews = async (req, res) => {
  try {
    const news = await SchoolNews.findById(req.params.id);
    if (!news) return res.status(404).json({ message: "News item not found" });

    if (
      news.createdBy.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({ message: "Not authorized to delete this news item" });
    }

    await news.deleteOne();
    res.json({ message: "News deleted successfully" });
  } catch (err) {
    console.error("Delete News Error:", err);
    res.status(500).json({ message: "Server error while deleting news." });
  }
};


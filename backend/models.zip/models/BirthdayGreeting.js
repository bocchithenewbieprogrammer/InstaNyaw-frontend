const mongoose = require("mongoose");

const birthdayGreetingSchema = new mongoose.Schema({
  recipient: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }, // 🎯 user being greeted
  message: { type: String, required: true },
  image: { type: String, default: "" }, // ✅ add optional image
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }, // 🎂 sender
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("BirthdayGreeting", birthdayGreetingSchema);

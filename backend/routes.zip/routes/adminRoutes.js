const express = require("express");
const router = express.Router();
const {
  getAllUsers,
  banUser,
  unbanUser,
  updateRole,
  deleteUser
} = require("../controllers/adminController");

const { protect } = require("../middleware/authMiddleware");

// Admin-only access
const adminOnly = (req, res, next) => {
  if (req.user.role !== "admin" && req.user.role !== "headadmin") {
    return res.status(403).json({ message: "Access denied: Admins only" });
  }
  next();
};

router.get("/users", protect, adminOnly, getAllUsers);
router.put("/ban/:id", protect, adminOnly, banUser);
router.put("/unban/:id", protect, adminOnly, unbanUser);
router.put("/role/:id", protect, adminOnly, updateRole);
router.delete("/delete/:id", protect, adminOnly, deleteUser);

module.exports = router;

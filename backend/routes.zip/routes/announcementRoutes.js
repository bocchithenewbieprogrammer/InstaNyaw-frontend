const express = require("express");
const router = express.Router();
const {
  createAnnouncement,
  getAnnouncements,
  updateAnnouncement,
  deleteAnnouncement,
} = require("../controllers/announcementController");
const { protect } = require("../middleware/authMiddleware");

// Admin creates announcement
router.post("/", protect, createAnnouncement);

// Get announcements (protected so only LCUP users can view)
router.get("/", protect, getAnnouncements);

// Admin updates
router.put("/:id", protect, updateAnnouncement);

// Admin deletes
router.delete("/:id", protect, deleteAnnouncement);

module.exports = router;

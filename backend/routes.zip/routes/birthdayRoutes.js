const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");

const {
  createGreeting,
  getGreetings,
  deleteGreeting,
  updateGreeting   // ✅ ADDED THIS
} = require("../controllers/birthdayController");

// CREATE
router.post("/", protect, createGreeting);

// READ
router.get("/", protect, getGreetings);

// UPDATE
router.put("/:id", protect, updateGreeting);

// DELETE
router.delete("/:id", protect, deleteGreeting);

module.exports = router;

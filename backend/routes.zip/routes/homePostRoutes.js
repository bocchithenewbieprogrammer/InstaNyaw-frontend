const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  createHomePost,
  getAllHomePosts,
  deleteHomePost,   // ⬅ ADD THIS
} = require("../controllers/homePostController");

router.post("/", protect, createHomePost);
router.get("/", protect, getAllHomePosts);
router.delete("/:id", protect, deleteHomePost); // ⬅ DELETE route

module.exports = router;

const express = require("express");
const router = express.Router();
const {
  createEntry,
  getEntries,
  updateEntry,
  deleteEntry,
} = require("../controllers/lostFoundController");
const { protect } = require("../middleware/authMiddleware");

// ✅ Create lost/found entry (user)
router.post("/", protect, createEntry);

// ✅ Get all entries
router.get("/", protect, getEntries);

// ✅ Update (owner or admin)
router.put("/:id", protect, updateEntry);

// ✅ Delete (owner or admin)
router.delete("/:id", protect, deleteEntry);

module.exports = router;

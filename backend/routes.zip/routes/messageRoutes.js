const express = require("express");
const router = express.Router();

const Conversation = require("../models/Conversation");
const Message = require("../models/Message");
const User = require("../models/User");

const { protect } = require("../middleware/authMiddleware");

// ---------------------------------------------
// GET all conversations for logged-in user
// ---------------------------------------------
router.get("/conversations", protect, async (req, res) => {
  try {
    const userId = req.user._id;

    const convs = await Conversation.find({
      participants: userId,
    })
      .populate("participants", "username avatar")
      .sort({ updatedAt: -1 })
      .lean();

    const conversations = await Promise.all(
      convs.map(async (c) => {
        const lastMsg = await Message.findOne({ conversation: c._id })
          .sort({ createdAt: -1 })
          .lean();

        const unreadCount = await Message.countDocuments({
          conversation: c._id,
          read: false,
          sender: { $ne: userId },
        });

        // Find the other participant
        const other = c.participants.find(
          (p) => p && p._id.toString() !== userId.toString()
        );

        return {
          _id: c._id,
          participants: c.participants,
          title: other?.username || "Unknown",
          avatar: other?.avatar || "images/default.png",
          lastMessage: lastMsg || null,
          unreadCount,
        };
      })
    );

    res.json(conversations);
  } catch (err) {
    console.error("Error loading conversations:", err);
    res.status(500).json({ message: "Failed to load conversations" });
  }
});

// ---------------------------------------------
// GET messages for a conversation
// ---------------------------------------------
router.get("/conversations/:id/messages", protect, async (req, res) => {
  try {
    const convId = req.params.id;

    const messages = await Message.find({
      conversation: convId,
    })
      .populate("sender", "username avatar")
      .sort({ createdAt: 1 });

    res.json(messages);
  } catch (err) {
    console.error("Error loading messages:", err);
    res.status(500).json({ message: "Failed to load messages" });
  }
});

// ---------------------------------------------
// SEND message
// ---------------------------------------------
router.post("/conversations/:id/messages", protect, async (req, res) => {
  try {
    const convId = req.params.id;
    const { content, image } = req.body;

    if (!content && !image) {
      return res.status(400).json({ message: "Message cannot be empty" });
    }

    const newMessage = await Message.create({
      conversation: convId,
      sender: req.user._id,
      content,
      image: image || "",
    });

    await Conversation.findByIdAndUpdate(convId, {
      updatedAt: new Date(),
    });

    res.status(201).json(newMessage);
  } catch (err) {
    console.error("Error sending message:", err);
    res.status(500).json({ message: "Failed to send message" });
  }
});

// ---------------------------------------------
// CREATE conversation
// ---------------------------------------------
router.post("/conversations", protect, async (req, res) => {
  try {
    const { targetUserId } = req.body;

    if (!targetUserId) {
      return res.status(400).json({ error: "targetUserId is required" });
    }

    const target = await User.findById(targetUserId);
    if (!target) {
      return res.status(404).json({ error: "User not found" });
    }

    // find existing conversation
    const existing = await Conversation.findOne({
      participants: { $all: [req.user._id, targetUserId] },
    });

    if (existing) return res.json(existing);

    // create new one
    const conv = await Conversation.create({
      participants: [req.user._id, targetUserId],
    });

    res.json(conv);
  } catch (err) {
    console.error("Conversation create error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;

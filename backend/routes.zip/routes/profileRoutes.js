// routes/profileRoutes.js
const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  getMyProfile,
  updateMyProfile,
  updateAvatar,
  getPublicProfile,
  getMyPosts   // ⭐ ADD THIS
} = require("../controllers/profileController");

// ✅ Get current user profile
router.get("/me", protect, getMyProfile);

// ✅ Update user profile (username, bio, password)
router.put("/update", protect, updateMyProfile);

// ✅ Upload avatar
router.put("/avatar", protect, updateAvatar);

// ✅ Get public profile by ID
router.get("/:id", getPublicProfile);

router.get("/myposts", protect, getMyPosts);


module.exports = router;

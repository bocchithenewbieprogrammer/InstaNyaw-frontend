const express = require("express");
const router = express.Router();
const {
  createNews,
  getNews,
  updateNews,
  deleteNews,
} = require("../controllers/schoolNewsController");
const { protect } = require("../middleware/authMiddleware");


// Create news (admin or staff)
router.post("/", protect, createNews);

// Get all news (protected)
router.get("/", protect, getNews);

// Update news (admin or staff)
router.put("/:id", protect, updateNews);

// Delete news (admin only)
router.delete("/:id", protect, deleteNews);

module.exports = router;

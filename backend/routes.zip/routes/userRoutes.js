// backend/routes/userRoutes.js
const express = require('express');
const router = express.Router();
const { listUsers } = require('../controllers/usersController');
const { protect } = require('../middleware/authMiddleware');

// GET /api/users
router.get('/', protect, listUsers);

module.exports = router;

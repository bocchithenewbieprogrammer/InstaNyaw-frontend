// routes/users.js
const express = require("express");
const router = express.Router();
const User = require("../models/User"); // adjust path if your model is elsewhere

// Optional: a small helper to escape regex chars in the query
function escapeRegex(text = "") {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * GET /api/users/search?query=...
 * Returns up to 20 users matching username / fullName / email (case-insensitive).
 * This endpoint accepts an optional Authorization header - but does not require it.
 */
router.get("/search", async (req, res) => {
  try {
    const q = (req.query.query || "").trim();
    if (!q) return res.json([]);

    const regex = new RegExp(escapeRegex(q), "i");

    // Search across a few sensible fields; adapt names if your schema differs
    const users = await User.find({
      $or: [
        { username: regex },
        { fullName: regex },   // optional field - remove if you don't have it
        { email: regex }
      ]
    })
      .select("_id username avatar") // return only necessary fields
      .limit(20)
      .lean();

    return res.json(users);
  } catch (err) {
    console.error("User search error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
